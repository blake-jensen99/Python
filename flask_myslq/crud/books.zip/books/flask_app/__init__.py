from flask import Flask

DB= 'books'




app = Flask(__name__)