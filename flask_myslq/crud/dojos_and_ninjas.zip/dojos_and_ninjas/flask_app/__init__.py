from flask import Flask

DB= 'dojo_and_ninjas'

app = Flask(__name__)